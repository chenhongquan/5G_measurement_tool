#include <linux/module.h>
#include <net/tcp.h>
#include <linux/inet_diag.h>
#include <linux/inet.h>
#include <linux/random.h>
#include <linux/win_minmax.h>

#define BW_SCALE 24
#define BW_UNIT (1 << BW_SCALE)

#define EXLL_SCALE 8
#define EXLL_UNIT (1 << EXLL_SCALE)

/* Skip TSO below the following bandwidth (bits/sec): */
static const int exll_min_tso_rate = 1200000;



struct exll{
	u32	min_rtt_us;	        /* min RTT in min_rtt_win_sec window */
	u32	min_rtt_stamp;	        /* timestamp of min_rtt_us */
	struct minmax bw;	/* Max recent delivery rate in pkts/uS << 24 */
	u32	rtt_cnt;	    /* count of packet-timed rounds elapsed */
	u32     next_rtt_delivered; /* scb->tx.delivered at end of round */
	
	u32    	prev_ca_state:3,     /* CA state on previous ACK */
		round_start:1,	     /* start of packet-timed tx->ack round? */
		tso_segs_goal:7,
		packet_cnt:8,
		sr_cnt:7,
		sr_prd_found:1,
		full_bw_cnt:3,
		max_tput_found:1,
		unused:1;	
	u32	sr_prd;	/* recent bw, to estimate if pipe is full */
	
	u32	full_bw;
	u32	cwnd_est;
	u32	rtt_comp_us;

	u64	rtt_mstamp;
	u32	ewma_bw;
	u32	gain;
};

static const int exll_bw_rtts = 8;

static const u32 exll_full_bw_thresh = EXLL_UNIT * 5 / 4;
static const u32 exll_full_bw_cnt = 2;

int sysctl_tcp_exll_gamma __read_mostly = 5;
int sysctl_tcp_exll_rttmin_gain_us __read_mostly = 5000;
int sysctl_tcp_exll_alpha __read_mostly = 200;

static void exll_update_min_rtt(struct sock *sk, const struct rate_sample * rs)
{
        struct tcp_sock *tp = tcp_sk(sk);
        struct exll *exll = inet_csk_ca(sk);
        
        if ( rs->rtt_us > 0 && (rs->rtt_us <= exll->min_rtt_us )) {
                exll->min_rtt_us = rs->rtt_us;
                exll->min_rtt_stamp = tcp_jiffies32;
		//exll->rtt_comp_us = exll->min_rtt_us + sysctl_tcp_exll_rttmin_gain_us;

		if( exll->sr_prd_found ) exll->rtt_comp_us = exll->min_rtt_us + exll->sr_prd;
        }

	if( exll->packet_cnt <= 70 ) exll->packet_cnt++;

	if( exll->packet_cnt <= 70 && rs->rtt_us > 0 ){
		exll->sr_cnt++;
		exll->sr_prd += rs->rtt_us;
	}

	if( exll->packet_cnt > 70 && !exll->sr_prd_found ){
		exll->sr_prd_found = 1;

		//5G extension
		/*exll->sr_prd /= exll->sr_cnt;
		exll->sr_prd -= exll->min_rtt_us;

		if ( 2 * exll->sr_prd < 5000 ) exll->sr_prd = 5000;
		else if( 2 * exll->sr_prd < 13000 ) exll->sr_prd = 10000;
		else if( 2 * exll->sr_prd < 25000 ) exll->sr_prd = 20000;
		else if( 2 * exll->sr_prd < 45000 ) exll->sr_prd = 40000;
		else exll->sr_prd = 80000;*/

		exll->sr_prd = sysctl_tcp_exll_rttmin_gain_us;
		exll->rtt_comp_us = exll->min_rtt_us + exll->sr_prd;
	}
	else if( exll->packet_cnt <= 100 && !exll->sr_prd_found ) {
		exll->rtt_comp_us = exll->min_rtt_us + sysctl_tcp_exll_rttmin_gain_us;
	}

}


/* Return the windowed max recent bandwidth sample, in pkts/uS << BW_SCALE. */
static u32 exll_max_bw(const struct sock *sk)
{
	struct exll *exll = inet_csk_ca(sk);

	return minmax_get(&exll->bw);
}

/* Return the estimated bandwidth of the path, in pkts/uS << BW_SCALE. */
static u32 exll_bw(const struct sock *sk)
{
	struct exll *exll = inet_csk_ca(sk);

	return exll_max_bw(sk);
}

static u32 exll_tso_segs_goal(struct sock *sk)
{
        struct exll *exll = inet_csk_ca(sk);

        return exll->tso_segs_goal;
}

static void exll_set_tso_segs_goal(struct sock *sk)
{
        struct tcp_sock *tp = tcp_sk(sk);
        struct exll *exll = inet_csk_ca(sk);
        u32 min_segs;

        min_segs = sk->sk_pacing_rate < (exll_min_tso_rate >> 3) ? 1 : 2;
        exll->tso_segs_goal = min(tcp_tso_autosize(sk, tp->mss_cache, min_segs),
                                 0x7FU);
}

static bool exll_full_bw_reached(const struct sock *sk)
{
        const struct exll *exll = inet_csk_ca(sk);

        return exll->full_bw_cnt >= exll_full_bw_cnt;
}

static void exll_check_full_bw_reached(struct sock *sk,
                                      const struct rate_sample *rs)
{
        struct exll *exll = inet_csk_ca(sk);
        u32 bw_thresh;

        if (exll_full_bw_reached(sk) || !exll->round_start || rs->is_app_limited)
                return;

        bw_thresh = (u64)exll->full_bw * exll_full_bw_thresh >> EXLL_SCALE;
        if (exll_max_bw(sk) >= bw_thresh) {
                exll->full_bw = exll_max_bw(sk);
                exll->full_bw_cnt = 0;
                return;
        }
        ++exll->full_bw_cnt;
}

/* Find target cwnd. Right-size the cwnd based on min RTT and the
 * estimated bottleneck bandwidth:
 *
 * cwnd = bw * min_rtt * gain = BDP * gain
 *
 * The key factor, gain, controls the amount of queue. While a small gain
 * builds a smaller queue, it becomes more vulnerable to noise in RTT
 * measurements (e.g., delayed ACKs or other ACK compression effects). This
 * noise may cause BBR to under-estimate the rate.
 *
 * To achieve full performance in high-speed paths, we budget enough cwnd to
 * fit full-sized skbs in-flight on both end hosts to fully utilize the path:
 *   - one skb in sending host Qdisc,
 *   - one skb in sending host TSO/GSO engine
 *   - one skb being received by receiver host LRO/GRO/delayed-ACK engine
 * Don't worry, at low rates (bbr_min_tso_rate) this won't bloat cwnd because
 * in such cases tso_segs_goal is 1. The minimum cwnd is 4 packets,
 * which allows 2 outstanding 2-packet sequences, to try to keep pipe
 * full even with ACK-every-other-packet delayed ACKs.
 */
static u32 exll_target_cwnd(struct sock *sk, u32 bw)
{
	struct exll *exll = inet_csk_ca(sk);
	u32 cwnd;
	u64 w;

	/* If we've never had a valid RTT sample, cap cwnd at the initial
	 * default. This should only happen when the connection is not using TCP
	 * timestamps and has retransmitted all of the SYN/SYNACK/data packets
	 * ACKed so far. In this case, an RTO can cut cwnd to 1, in which
	 * case we need to slow-start up toward something safe: TCP_INIT_CWND.
	 */
	if (unlikely(exll->min_rtt_us == ~0U))	 /* no valid RTT samples yet? */
		return TCP_INIT_CWND;  /* be safe: cap at default initial cwnd*/

	w = (u64)bw * exll->min_rtt_us;

	/* Apply a gain to the given value, then remove the BW_SCALE shift. */
	cwnd = (((w * exll->gain) >> EXLL_SCALE) + BW_UNIT - 1) / BW_UNIT;

	/* Allow enough full-sized skbs in flight to utilize end systems. */
	cwnd += 3 * exll->tso_segs_goal;

	/* Reduce delayed ACKs by rounding up cwnd to the next even number. */
	cwnd = (cwnd + 1) & ~1U;

	return cwnd;
}


/* Slow-start up toward target cwnd (if bw estimate is growing, or packet loss
 * has drawn us down below target), or snap down to target if we're above it.
 */
static void exll_set_cwnd(struct sock *sk, const struct rate_sample *rs,
			 u32 acked, u32 bw)
{
	struct tcp_sock *tp = tcp_sk(sk);
	struct exll *exll = inet_csk_ca(sk);
	u32 cwnd = 0, target_cwnd = 0;


	if (!acked)
		return;

	cwnd = tp->snd_cwnd;

	if( !exll->max_tput_found ){
	        if (!tcp_is_cwnd_limited(sk))	return;
		if (rs->is_app_limited)	return;

		//target_cwnd = exll_target_cwnd(sk, bw);
		//cwnd = min(cwnd + acked, target_cwnd);

		cwnd = cwnd + acked;

		tp->snd_cwnd = cwnd;
	}
	else{
		cwnd = exll->cwnd_est;
		do_div(cwnd, tp->advmss);

		tp->snd_cwnd = cwnd;
	}


}


/* Estimate the bandwidth based on how fast packets are delivered */
static void exll_update_bw(struct sock *sk, const struct rate_sample *rs)
{
	struct tcp_sock *tp = tcp_sk(sk);
	struct exll *exll = inet_csk_ca(sk);
	u64 bw;

	u64 cwnd1 = 0;

	exll->round_start = 0;
	if (rs->delivered < 0 || rs->interval_us <= 0)
		return; /* Not a valid observation */

	/* See if we've reached the next RTT */
	if (!before(rs->prior_delivered, exll->next_rtt_delivered)) {
		exll->next_rtt_delivered = tp->delivered;
		exll->rtt_cnt++;
		exll->round_start = 1;
	}

	/* Divide delivered by the interval to find a (lower bound) bottleneck
	 * bandwidth sample. Delivered is in packets and interval_us in uS and
	 * ratio will be <<1 for most connections. So delivered is first scaled.
	 */
	bw = (u64)rs->delivered * BW_UNIT;
	do_div(bw, rs->interval_us);


	/* If this sample is application-limited, it is likely to have a very
	 * low delivered count that represents application behavior rather than
	 * the available network rate. Such a sample could drag down estimated
	 * bw, causing needless slow-down. Thus, to continue to send at the
	 * last measured network rate, we filter out app-limited samples unless
	 * they describe the path bw at least as well as our bw model.
	 *
	 * So the goal during app-limited phase is to proceed with the best
	 * network rate no matter how long. We automatically leave this
	 * phase when app writes faster than the network can deliver :)
	 */
	if (!rs->is_app_limited || bw >= exll_max_bw(sk)) {
		/* Incorporate new sample into our max bw filter. */
		minmax_running_max(&exll->bw, exll_bw_rtts, exll->rtt_cnt, bw);
	}

	if( !exll->max_tput_found ){
		exll_check_full_bw_reached(sk,rs);
		cwnd1 = (u64)exll_bw(sk) * exll->rtt_comp_us * tp->advmss;
		do_div(cwnd1, BW_UNIT);
		exll->cwnd_est = cwnd1;
		exll->ewma_bw = exll_bw(sk);

		if( exll_full_bw_reached(sk) ){
			exll->max_tput_found = 1;
			exll->gain = EXLL_UNIT;
		}
	}
	else{
		exll->ewma_bw -= exll->ewma_bw >> 3;
		exll->ewma_bw += bw >> 3;
	}

}

static void exll_control(struct sock *sk, const struct rate_sample *rs)
{

	struct tcp_sock *tp = tcp_sk(sk);
	struct exll *exll = inet_csk_ca(sk);
	
	u64 cwnd1 = 0 , cwnd2 = 0;
	
	if( exll->max_tput_found ){

		if( exll->rtt_mstamp == 0 ) exll->rtt_mstamp = tp->delivered_mstamp;

		//Run this control equation only one time per RTT
		//if( tcp_stamp_us_delta(tp->delivered_mstamp, exll->rtt_mstamp) < rs->rtt_us ) return;
		//else exll->rtt_mstamp = tp->delivered_mstamp;

		if( !exll->round_start ) return;

		if( (exll->min_rtt_us == 0) || (rs->rtt_us < exll->rtt_comp_us) ){
			cwnd1 = ((u64)exll->cwnd_est * sysctl_tcp_exll_gamma);
			do_div(cwnd1, 10);
		}
		else {
			cwnd1 = ((u64)exll->rtt_comp_us * sysctl_tcp_exll_gamma);
			do_div(cwnd1, 10);
			cwnd1 *= exll->cwnd_est;
	
			do_div(cwnd1, rs->rtt_us);
		}
		
		if( exll->ewma_bw >= exll_bw(sk) || !exll_bw(sk) ) cwnd2 = 0;
		else {
			cwnd2 = exll->ewma_bw * sysctl_tcp_exll_alpha * tp->advmss;
			do_div(cwnd2, exll_bw(sk));
			cwnd2 = sysctl_tcp_exll_alpha * tp->advmss - cwnd2;
			//Deleted at 2019/10/16.
			//do_div(cwnd2, exll->rtt_comp_us);
			
			cwnd2 *= sysctl_tcp_exll_gamma;
			do_div(cwnd2, 10);
		}
		
	
		exll->cwnd_est = (10 - sysctl_tcp_exll_gamma) * exll->cwnd_est;
		do_div(exll->cwnd_est, 10);
		exll->cwnd_est += cwnd1 + cwnd2;
	}

        printk(KERN_WARNING "ExLL Ctl: %d %u %lu %u %u %u %lu %lu %d %d\n", ntohs((tp->inet_conn).icsk_inet.inet_sport), exll->cwnd_est, exll->ewma_bw, exll_bw(sk), rs->rtt_us, exll->rtt_comp_us, cwnd1, cwnd2, exll->max_tput_found, tp->advmss);

}

static u64 exll_rate_bytes_per_sec(struct sock *sk, u64 rate)
{
        rate *= tcp_mss_to_mtu(sk, tcp_sk(sk)->mss_cache);
        rate *= USEC_PER_SEC;
        return rate >> BW_SCALE;
}


static u32 exll_bw_to_pacing_rate(struct sock *sk, const struct rate_sample *rs)
{

        struct exll *exll = inet_csk_ca(sk);

        u64 rate = (u64)exll->cwnd_est * BW_UNIT;

	do_div(rate, rs->rtt_us);

        rate = exll_rate_bytes_per_sec(sk, rate);
        rate = min_t(u64, rate, sk->sk_max_pacing_rate);
        return rate;
}


static void exll_set_pacing_rate(struct sock *sk, const struct rate_sample *rs)
{
        u32 rate = exll_bw_to_pacing_rate(sk, rs);

        sk->sk_pacing_rate = rate;
}


static void exll_main(struct sock *sk, const struct rate_sample *rs)
{
	struct exll *exll = inet_csk_ca(sk);
        struct tcp_sock *tp = tcp_sk(sk);


	exll_update_min_rtt(sk, rs);

	exll_update_bw(sk, rs);
	exll_control(sk, rs);

	exll_set_tso_segs_goal(sk);
	exll_set_pacing_rate(sk, rs);
	exll_set_cwnd(sk, rs, rs->acked_sacked, exll->cwnd_est);

        printk(KERN_WARNING "DEBUG: %d %u %u %u %u %u %u %u %d \n", ntohs((tp->inet_conn).icsk_inet.inet_sport), exll->cwnd_est, exll_bw(sk), tp->snd_cwnd, rs->rtt_us, exll->min_rtt_us, exll->rtt_comp_us, exll->sr_prd, exll->max_tput_found);

}

static void exll_init(struct sock *sk)
{
	struct tcp_sock *tp = tcp_sk(sk);
	struct exll *exll = inet_csk_ca(sk);


	if( !exll->max_tput_found ){
		exll->rtt_cnt = 0;
		exll->next_rtt_delivered = 0;
		exll->prev_ca_state = TCP_CA_Open;

		exll->min_rtt_us = 1000000;
		exll->min_rtt_stamp = 0;
		exll->rtt_comp_us = 0;

		minmax_reset(&exll->bw, exll->rtt_cnt, 0);  /* init max bw to 0 */

		exll->cwnd_est = 10 * tp->advmss;	
		exll->round_start = 0;
		exll->packet_cnt = 0;
		exll->sr_prd = 0;
		exll->sr_prd_found = 0;
		exll->packet_cnt = 0;

		exll->full_bw = 0;
		exll->full_bw_cnt = 0;
		exll->max_tput_found = 0;

		exll->rtt_mstamp = 0;
		exll->ewma_bw = 0;
		exll->gain = 2 * EXLL_UNIT;
	}

	//cmpxchg(&sk->sk_pacing_status, SK_PACING_NONE, SK_PACING_NEEDED);
}

static u32 exll_sndbuf_expand(struct sock *sk)
{
	/* Provision 3 * cwnd since BBR may slow-start even during recovery. */
	return 3;
}

/* In theory BBR does not need to undo the cwnd since it does not
 * always reduce cwnd on losses (see bbr_main()). Keep it for now.
 */
static u32 exll_undo_cwnd(struct sock *sk)
{
	return tcp_sk(sk)->snd_cwnd;
}

/* Entering loss recovery, so save cwnd for when we exit or undo recovery. */
static u32 exll_ssthresh(struct sock *sk)
{
	return TCP_INFINITE_SSTHRESH;	 /* BBR does not use ssthresh */
}

static void exll_set_state(struct sock *sk, u8 new_state)
{
	struct exll *exll = inet_csk_ca(sk);

	if (new_state == TCP_CA_Loss) {
		struct rate_sample rs = { .losses = 1 };

		exll->prev_ca_state = TCP_CA_Loss;
	}
}

static struct tcp_congestion_ops tcp_exll_cong_ops __read_mostly = {
	.flags		= TCP_CONG_NON_RESTRICTED,
	.name		= "exll",
	.owner		= THIS_MODULE,
	.init		= exll_init,
	.cong_control	= exll_main,
	.sndbuf_expand	= exll_sndbuf_expand,
	.undo_cwnd	= exll_undo_cwnd,
	//.cwnd_event	= exll_cwnd_event,
	.ssthresh	= exll_ssthresh,
	.tso_segs_goal  = exll_tso_segs_goal,
	//.get_info	= exll_get_info,
	.set_state	= exll_set_state,
};

static int __init exll_register(void)
{
	BUILD_BUG_ON(sizeof(struct exll) > ICSK_CA_PRIV_SIZE);
	return tcp_register_congestion_control(&tcp_exll_cong_ops);
}

static void __exit exll_unregister(void)
{
	tcp_unregister_congestion_control(&tcp_exll_cong_ops);
}

module_init(exll_register);
module_exit(exll_unregister);

MODULE_AUTHOR("Shinik Park <sipark@unist.ac.kr>");
MODULE_AUTHOR("Junseon Kim <jskim@unist.ac.kr");
MODULE_AUTHOR("Kyunghan Lee <khlee@unist.ac.kr");
MODULE_LICENSE("Dual BSD/GPL");
MODULE_DESCRIPTION("TCP ExLL");    
